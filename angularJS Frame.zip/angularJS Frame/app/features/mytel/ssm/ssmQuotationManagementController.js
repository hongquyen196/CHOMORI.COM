/**
 * Created by hienpt on 4/19/17.
 */
angular
    .module('altairApp')
    .controller('ssmQuotationManagementCtrl', [
        '$rootScope',
        '$window',
        '$scope',
        function ($rootScope, $scope, $window) {
            console.log("Start dashboard controller");

        }
    ])
;