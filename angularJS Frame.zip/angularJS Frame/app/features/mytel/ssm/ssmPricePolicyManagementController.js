/**
 * Created by hienpt on 4/19/17.
 */
angular
    .module('altairApp')
    .controller('ssmPricePolicyManagementCtrl', [
        '$scope',
        '$timeout',
        function ($scope, $timeout) {

        }
    ]).controller('gmap_neutralBlueCtrl', [
        '$scope',
        '$timeout',
        function ($scope, $timeout) {
        }
    ])
;