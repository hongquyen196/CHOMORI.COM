/**
 * Created by hienpt on 4/19/17.
 */
angular
    .module('altairApp', [])
    .controller('cimCtrl', [
        '$scope',
        '$rootScope',
        '$timeout',
        '$compile',
        '$http',
        'variables',
        function ($scope, $rootScope, $timeout, $compile, $http, variables) {

            //Begin Combobox
            $scope.usersDataSource = {
                serverFiltering: true,
                transport: {
                    read: {
                        url: "data/kUI_users_data.min.json"
                    }
                }
            };

            //End Combobox

            //Begin Datatimepicker
            //$scope.monthSelectorOptions = {
            //    start: "year",
            //    depth: "year"
            //};
            //$scope.getType = function(x) {
            //    return typeof x;
            //};
            //$scope.isDate = function(x) {
            //    return x instanceof Date;
            //};
            //End Datatimepicker

            //$scope.newData = [
            //    {
            //        "first": "something1",
            //        "second": "one"
            //    },
            //    {
            //        "first": "something2",
            //        "second": "two"
            //    },
            //    {
            //        "first": "something3",
            //        "second": "three"
            //    },
            //    {
            //        "first": "something4",
            //        "second": "four"
            //    }
            //];
            $scope.showFunc = function (iterator) {
                iterator.show = !iterator.show;
            };

            $scope.editSelected = function () {
                $scope.newData.filter(function (iterator) {
                    return iterator.selected;
                }).forEach(function (item) {
                    item.show = true;
                });
            };
            $scope.tableSelection = {};

            $scope.isAll = false;
            $scope.selectAllRows = function () {
                //check if all selected or not
                if ($scope.isAll === false) {
                    //set all row selected
                    angular.forEach($scope.newData, function (row, index) {
                        $scope.tableSelection[index] = true;
                    });
                    $scope.isAll = true;
                } else {
                    //set all row unselected
                    angular.forEach($scope.newData, function (row, index) {
                        $scope.tableSelection[index] = false;
                    });
                    $scope.isAll = false;
                }
            };

            $scope.removeSelectedRows = function () {
                //start from last index because starting from first index cause shifting
                //in the array because of array.splice()
                for (var i = $scope.newData.length - 1; i >= 0; i--) {
                    if ($scope.tableSelection[i]) {
                        //delete row from data
                        $scope.newData.splice(i, 1);
                        //delete rowSelection property
                        delete $scope.tableSelection[i];
                    }
                }
            };

            //
            //$scope.alignChar_customers = [
            //    ["abc 123", ".423475", "Koala = cute = cudley", "search.google.com"],
            //    ["abc 1", "23.4", "Ox = stinky", "mail.yahoo.com"],
            //    ["bc 9", "1.0", "Girafee = tall", "http://www.facebook.com"],
            //    ["zyx 24", "7.67", "Bison = burger", "http://internship.whitehouse.gov/"],
            //    ["abc 11", "3000", "Chimp = banana lover", "about.ucla.edu"],
            //    ["abc 2", "56.5", "Elephant = unforgetable", "http://www.wikipedia.org/"],
            //    ["abc 9", "15.5", "Lion = rawr", "rental.nytimes.com/index.html"],
            //    ["ABC 10", "87.20000", "Zebra = stripey", "http://android.google.com"],
            //    ["zyx 1", "999.1", "Koala = cute, again!", "http://irsmrt.mit.edu/"],
            //    ["zyx 12", "0.2", "Llama = llove it", "http://aliens.nasa.gov/"]
            //];
            //
            //$scope.customFilters_customers = [
            //    ['abc 123', '10', 'Koala', 'Mar 5, 2014'],
            //    ['abc 1', '234', 'Ox', 'Jan 2, 2014'],
            //    ['abc 9', '10', 'Girafee', 'Sep 20, 2013'],
            //    ['zyx 24', '767', 'Bison', 'Apr 8, 2014'],
            //    ['abc 11', '3', 'Chimp', 'Feb 5, 2014'],
            //    ['abc 2', '56', 'Elephant', 'Dec 18, 2013'],
            //    ['abc 9', '155', 'Lion', 'Mar 18, 2014'],
            //    ['ABC 10', '87', 'Zebra', 'Jul 1, 2014'],
            //    ['zyx 1', '999', 'Koala', 'Jan 18, 2014'],
            //    ['zyx 12', '0', 'Llama', 'Jan 20, 2015']
            //];

            // initialize tables
            $scope.$on('onLastRepeat', function (scope, element, attrs) {

                var $ts_pager_filter = $("#ts_pager_filter"),
                    $ts_align = $('#ts_align'),
                    $ts_customFilters = $('#ts_custom_filters'),
                    $columnSelector = $('#columnSelector');

                // pager + filter
                if ($(element).closest($ts_pager_filter).length) {

                    // define pager options
                    var pagerOptions = {
                        // target the pager markup - see the HTML block below
                        container: $(".ts_pager"),
                        // output string - default is '{page}/{totalPages}'; possible variables: {page}, {totalPages}, {startRow}, {endRow} and {totalRows}
                        output: '{startRow} - {endRow} / {filteredRows} ({totalRows})',
                        // if true, the table will remain the same height no matter how many records are displayed. The space is made up by an empty
                        // table row set to a height to compensate; default is false
                        fixedHeight: true,
                        // remove rows from the table to speed up the sort of large tables.
                        // setting this to false, only hides the non-visible rows; needed if you plan to add/remove rows with the pager enabled.
                        removeRows: false,
                        // go to page selector - select dropdown that sets the current page
                        cssGoto: '.ts_gotoPage'
                    };

                    // change popup print & close button text
                    $.tablesorter.language.button_print = "Print table";
                    $.tablesorter.language.button_close = "Cancel";

                    // print table
                    $('#printTable').on('click', function (e) {
                        e.preventDefault();
                        $ts_pager_filter.trigger('printTable');
                    });

                    // Initialize tablesorter
                    var ts_users = $ts_pager_filter
                        .tablesorter({
                            theme: 'altair',
                            widthFixed: true,
                            widgets: ['zebra', 'filter', 'print', 'columnSelector'],
                            headers: {
                                0: {
                                    sorter: false,
                                    parser: false
                                }
                            },
                            widgetOptions: {
                                // column selector widget
                                columnSelector_container: $columnSelector,
                                columnSelector_name: 'data-name',
                                columnSelector_layout: '<li class="padding_md"><input type="checkbox"><label class="inline-label">{name}</label></li>',
                                columnSelector_saveColumns: false,
                                // print widget
                                print_title: '',          // this option > caption > table id > "table"
                                print_dataAttrib: 'data-name', // header attrib containing modified header name
                                print_rows: 'f',         // (a)ll, (v)isible, (f)iltered, or custom css selector
                                print_columns: 's',         // (a)ll, (v)isible or (s)elected (columnSelector widget)
                                print_extraCSS: '',          // add any extra css definitions for the popup window here
                                print_styleSheet: '',          // add the url of your print stylesheet
                                print_now: true,        // Open the print dialog immediately if true
                                // callback executed when processing completes - default setting is null
                                print_callback: function (config, $table, printStyle) {
                                    // hide sidebar
                                    $rootScope.primarySidebarActive = false;
                                    $rootScope.primarySidebarOpen = false;
                                    $timeout(function () {
                                        // print the table using the following code
                                        $.tablesorter.printTable.printOutput(config, $table.html(), printStyle);
                                    }, 300);
                                }
                            }
                        })
                        // initialize the pager plugin
                        .tablesorterPager(pagerOptions)
                        .on('pagerComplete', function (e, filter) {
                            // update selectize value
                            if (typeof selectizeObj !== 'undefined' && selectizeObj.data('selectize')) {
                                selectizePage = selectizeObj[0].selectize;
                                selectizePage.setValue($('select.ts_gotoPage option:selected').index() + 1, false);
                            }
                        });

                    // replace column selector checkboxes
                    $columnSelector.children('li').each(function (index) {
                        var $this = $(this);

                        var id = index == 0 ? 'auto' : index;
                        $this.children('input').attr('id', 'column_' + id);
                        $this.children('label').attr('for', 'column_' + id);

                        $this.children('input')
                            .prop('checked', true)
                            .iCheck({
                                checkboxClass: 'icheckbox_md',
                                radioClass: 'iradio_md',
                                increaseArea: '20%'
                            });

                        if (index != 0) {
                            $this.find('input')
                                .on('ifChanged', function (ev) {
                                    $(ev.target).toggleClass('checked').change();
                                })
                        }

                    });

                    $('#column_auto')
                        .on('ifChecked', function (ev) {
                            $(this)
                                .closest('li')
                                .siblings('li')
                                .find('input').iCheck('disable');
                            $(ev.target).removeClass('checked').change();
                        })
                        .on('ifUnchecked', function (ev) {
                            $(this)
                                .closest('li')
                                .siblings('li')
                                .find('input').iCheck('enable');
                            $(ev.target).addClass('checked').change();
                        });

                    // replace 'goto Page' select
                    function createPageSelectize() {
                        selectizeObj = $('select.ts_gotoPage')
                            .val($("select.ts_gotoPage option:selected").val())
                            .after('<div class="selectize_fix"></div>')
                            .selectize({
                                hideSelected: true,
                                onDropdownOpen: function ($dropdown) {
                                    $dropdown
                                        .hide()
                                        .velocity('slideDown', {
                                            duration: 200,
                                            easing: variables.easing_swiftOut
                                        })
                                },
                                onDropdownClose: function ($dropdown) {
                                    $dropdown
                                        .show()
                                        .velocity('slideUp', {
                                            duration: 200,
                                            easing: variables.easing_swiftOut
                                        });

                                    // hide tooltip
                                    $('.uk-tooltip').hide();
                                }
                            });
                    }

                    createPageSelectize();

                    // replace 'pagesize' select
                    $('.pagesize.ts_selectize')
                        .after('<div class="selectize_fix"></div>')
                        .selectize({
                            hideSelected: true,
                            onDropdownOpen: function ($dropdown) {
                                $dropdown
                                    .hide()
                                    .velocity('slideDown', {
                                        duration: 200,
                                        easing: variables.easing_swiftOut
                                    })
                            },
                            onDropdownClose: function ($dropdown) {
                                $dropdown
                                    .show()
                                    .velocity('slideUp', {
                                        duration: 200,
                                        easing: variables.easing_swiftOut
                                    });

                                // hide tooltip
                                $('.uk-tooltip').hide();

                                if (typeof selectizeObj !== 'undefined' && selectizeObj.data('selectize')) {
                                    selectizePage = selectizeObj[0].selectize;
                                    selectizePage.destroy();
                                    $('.ts_gotoPage').next('.selectize_fix').remove();
                                    setTimeout(function () {
                                        createPageSelectize()
                                    })
                                }

                            }
                        });

                    // select/unselect table rows
                    $('.ts_checkbox_all')
                        .iCheck({
                            checkboxClass: 'icheckbox_md',
                            radioClass: 'iradio_md',
                            increaseArea: '20%'
                        })
                        .on('ifChecked', function () {
                            $ts_pager_filter
                                .find('.ts_checkbox')
                                // check all checkboxes in table
                                .prop('checked', true)
                                .iCheck('update')
                                // add highlight to row
                                .closest('tr')
                                .addClass('row_highlighted');
                        })
                        .on('ifUnchecked', function () {
                            $ts_pager_filter
                                .find('.ts_checkbox')
                                // uncheck all checkboxes in table
                                .prop('checked', false)
                                .iCheck('update')
                                // remove highlight from row
                                .closest('tr')
                                .removeClass('row_highlighted');
                        });

                    // select/unselect table row
                    $ts_pager_filter.find('.ts_checkbox')
                        .on('ifUnchecked', function () {
                            $(this).closest('tr').removeClass('row_highlighted');
                            $('.ts_checkbox_all').prop('checked', false).iCheck('update');
                        }).on('ifChecked', function () {
                            $(this).closest('tr').addClass('row_highlighted');
                        });

                    //// remove single row
                    //$ts_pager_filter.on('click', '.ts_remove_row', function (e) {
                    //    e.preventDefault();
                    //
                    //    var $this = $(this);
                    //    UIkit.modal.confirm('Are you sure you want to delete this user?', function () {
                    //        $this.closest('tr').remove();
                    //        ts_users.trigger('update');
                    //    }, {
                    //        labels: {
                    //            'Ok': 'Delete'
                    //        }
                    //    });
                    //});

                    //// edit single row
                    //$ts_pager_filter.on('click', '.ts_edit_row', function (e) {
                    //    e.preventDefault();
                    //
                    //    $scope.openModal('popupEdit');
                    //    //var $this = $(this);
                    //    //UIkit.modal.confirm('Are you sure you want to edit this user?', function () {
                    //    //    $this.closest('tr').remove();
                    //    //    ts_users.trigger('update');
                    //    //}, {
                    //    //    labels: {
                    //    //        'Ok': 'Edit'
                    //    //    }
                    //    //});
                    //});
                }

                // align widget example
                if ($(element).closest($ts_align).length) {
                    $ts_align.tablesorter({
                        theme: 'altair',
                        widgets: ['zebra', 'alignChar'],
                        widgetOptions: {
                            alignChar_wrap: '<i/>',
                            alignChar_charAttrib: 'data-align-char',
                            alignChar_indexAttrib: 'data-align-index',
                            alignChar_adjustAttrib: 'data-align-adjust' // percentage width adjustments
                        }
                    });
                }

                // custom filters
                if ($(element).closest($ts_customFilters).length) {
                    $ts_customFilters
                        .tablesorter({
                            theme: 'altair',
                            headerTemplate: '{content} {icon}',
                            widgets: ['zebra', 'filter'],
                            widgetOptions: {
                                filter_reset: 'button.ts_cf_reset',
                                filter_cssFilter: ['', 'ts_cf_range', 'ts_cf_select_single', 'ts_cf_datepicker']
                            }
                        })
                        .on('apply.daterangepicker', function () {
                            $table.trigger('search');
                        });

                    // rangeSlider
                    var slider = $('.ts_cf_range').ionRangeSlider({
                        "min": "0",
                        "max": "1000",
                        "type": "double",
                        "grid-num": "10",
                        "from-min": "10",
                        "from-max": "30",
                        "input_values_separator": " - "
                    }).data("ionRangeSlider");

                    // selectize
                    var $selectize = $('.ts_cf_select_single')
                        .after('<div class="selectize_fix"></div>')
                        .selectize({
                            hideSelected: true,
                            dropdownParent: 'body',
                            closeAfterSelect: true,
                            onDropdownOpen: function ($dropdown) {
                                $dropdown
                                    .hide()
                                    .velocity('slideDown', {
                                        duration: 200,
                                        easing: [0.4, 0, 0.2, 1]
                                    })
                            },
                            onDropdownClose: function ($dropdown) {
                                $dropdown
                                    .show()
                                    .velocity('slideUp', {
                                        duration: 200,
                                        easing: [0.4, 0, 0.2, 1]
                                    });
                            }
                        });


                    var cf_selectize = $selectize[0].selectize;

                    var modal = UIkit.modal("#modal_daterange", {
                        center: true
                    });

                    $('.ts_cf_datepicker').on('focus', function () {
                        if (modal.isActive()) {
                            modal.hide();
                        } else {
                            modal.show();
                        }
                    });

                    //// model change
                    //
                    //$scope.forms_advanced.datepicker = "23/06/2016"
                    //
                    //
                    //// date range
                    //var $dp_start = $('#uk_dp_start'),
                    //    $dp_end = $('#uk_dp_end');
                    //
                    //var start_date = UIkit.datepicker($dp_start, {
                    //    format: 'DD/MM/YYYY'
                    //});
                    //
                    //var end_date = UIkit.datepicker($dp_end, {
                    //    format: 'DD/MM/YYYY'
                    //});
                    //
                    //$dp_start.on('change', function () {
                    //    end_date.options.minDate = $dp_start.val();
                    //});
                    //
                    //$dp_end.on('change', function () {
                    //    start_date.options.maxDate = $dp_end.val();
                    //});
                    //
                    //$('#daterangeApply').on('click', function (e) {
                    //    e.preventDefault();
                    //    modal.hide();
                    //    $('.ts_cf_datepicker').val(
                    //        $dp_start.val() + ' - ' + $dp_end.val()
                    //    ).change().blur();
                    //});
                    //
                    //$('button.ts_cf_reset').on('click', function () {
                    //    // reset selectize
                    //    cf_selectize.clear();
                    //    // slider reset
                    //    slider.reset();
                    //})
                }

            });

            // gets the template to ng-include for a table row / item
            //$scope.getTemplate = function (contact) {
            //    if (contact.id === $scope.model.selected.id) return 'edit';
            //    else return 'display';
            //};
            //
            //$scope.editContact = function (contact) {
            //    $scope.model.selected = angular.copy(contact);
            //};
            //
            //$scope.saveContact = function (idx) {
            //    console.log("Saving contact");
            //    $scope.model.contacts[idx] = angular.copy($scope.model.selected);
            //    $scope.reset();
            //};
            //
            //$scope.reset = function () {
            //    $scope.model.selected = {};
            //};

            // sQuyenLH1


            // setting data from API

            $scope.customers = [];
            $scope.customerTypes = [];
            $scope.typeOfInvestments = [];
            $scope.typeOfSales = [];

            /**
             *
             * @param txtSearch
             */
            $scope.getCustomers = function (txtSearch) {
                $scope.customers = [];
                $timeout(function () {
                    //$http.get("data/data_cim.json?page=0&size=20&sort=asc&column=customerName&txtSearch=" + txtSearch)
                    $http.get("http://203.81.74.34:8000/api/customers?page=0&size=20&sort=asc&column=customerName&txtSearch=" + txtSearch)
                        .then(function (response) {
                            if (response.data.meta.code === 200) {
                                $scope.customers = response.data.data.customerList;
                                console.log($scope.customers);
                            }
                        }, function responseError() {
                            alert("get Customers error!");
                        });
                }, 100);
            };

            /**
             * init
             */
            $scope.init = function () {
                $scope.getCustomers('');
                $http.get("http://203.81.74.34:8000/api/customer-types")
                    .then(function (response) {
                        if (response.data.meta.code === 200) {
                            $scope.customerTypes = response.data.data.customerTypes;
                        }
                    }, function responseError() {
                        alert("get customerTypes error!");
                    });
                $http.get("http://203.81.74.34:8000/api/customer-classifications?type=investment")
                    .then(function (response) {
                        if (response.data.meta.code === 200) {
                            $scope.typeOfInvestments = response.data.data.customerClassifications;
                        }
                    }, function responseError() {
                        alert("get typeOfInvestments error!");
                    });
                $http.get("http://203.81.74.34:8000/api/customer-classifications?type=sale")
                    .then(function (response) {
                        if (response.data.meta.code === 200) {
                            $scope.typeOfSales = response.data.data.customerClassifications;
                        }
                    }, function responseError() {
                        alert("get typeOfSales error!");
                    });
            };
            $scope.init();

            /**
             * removeCustomer
             * @param index
             */
            $scope.removeCustomer = function (index) {
                UIkit.modal.confirm('Are you sure you want to delete this user?', function () {
                    $http.delete("http://203.81.74.34:8000/api/customers/" + $scope.customers[idxCustomer].id)
                        .then(function (response) {
                            if (response.data.meta.code === 200) {
                                $scope.customers.splice(index, 1);
                                console.log($scope.customers);
                            }
                        }, function responseError() {
                            alert("delete customers error!");
                        });
                }, {
                    labels: {
                        'Ok': 'Delete'
                    }
                });
            };

            $scope.itemEdit = {};
            var idxCustomer = -1;

            /**
             * editCustomer
             * @type {number}
             */
            $scope.editCustomer = function (index) {
                idxCustomer = index;
                $scope.itemEdit = angular.copy($scope.customers[idxCustomer]);
                $scope.openModal('popupEdit');
            };

            /**
             * saveEditCustomer
             */
            $scope.saveEditCustomer = function () {
                $scope.customers[idxCustomer].customerTypeId = $scope.itemEdit.customerTypeId;
                $scope.customers[idxCustomer].typeOfInvestmentId = $scope.itemEdit.typeOfInvestmentId;
                $scope.customers[idxCustomer].typeOfSaleId = $scope.itemEdit.typeOfSaleId;
                $scope.customers[idxCustomer].customerStatus = $scope.itemEdit.customerStatus;
                $scope.customers[idxCustomer].customerName = $scope.itemEdit.customerName;
                $scope.customers[idxCustomer].address = $scope.itemEdit.address;
                $scope.customers[idxCustomer].catalog = $scope.itemEdit.catalog;
                $scope.customers[idxCustomer].customerStatus = $scope.itemEdit.customerStatus;
                $scope.customers[idxCustomer].contactName = $scope.itemEdit.contactName;
                $scope.customers[idxCustomer].phone = $scope.itemEdit.phone;
                $scope.customers[idxCustomer].email = $scope.itemEdit.email;
                $scope.customers[idxCustomer].position = $scope.itemEdit.position;
                $scope.customers[idxCustomer].service = $scope.itemEdit.service;
                $scope.customers[idxCustomer].customerDate = $scope.itemEdit.customerDate;
                $scope.itemEdit = {};
                $http.put("http://203.81.74.34:8000/api/customers/" + $scope.customers[idxCustomer].id, $scope.customers[idxCustomer])
                    .then(function (response) {
                        if (response.data.meta.code === 200) {
                            $scope.closeModal('popupEdit');
                        }
                    }, function responseError() {
                        alert("put customers error!");
                    });
            };

            /**
             * openModal
             * @param idName
             */
            $scope.openModal = function (idName) {
                document.getElementById(idName).style.display = "block";
            };

            /**
             * closeModal
             * @param idName
             */
            $scope.closeModal = function (idName) {
                document.getElementById(idName).style.display = "none";
            };

            // add new customer
            $scope.itemCreate = {
                customerTypeId: 1,
                typeOfSaleId: 1,
                typeOfInvestmentId: 1,
                customerStatus: 0,
                status: 0,
                customerDate: "2018-07-08"
            };

            /**
             * createCustomer
             */
            $scope.createCustomer = function () {
                var itemCreate = angular.copy($scope.itemCreate);
                console.log(itemCreate);
                $http.post("http://203.81.74.34:8000/api/customers", itemCreate)
                    .then(function (response) {
                        if (response.data.meta.code === 200) {
                            $scope.customers.push(itemCreate);
                            console.log(itemCreate);
                        }
                    }, function responseError() {
                        alert("post customers error!");
                    });
            };

            //search customer
            $scope.itemCustomer = {
                customerTypeId: 1,
                typeOfInvestmentId: 1,
                customerStatus: 0
            };

            /**
             * searchCustomer
             */
            $scope.searchCustomer = function () {
                var itemSearch = angular.copy($scope.itemCustomer);
                $scope.getCustomers(itemSearch.customerName);
            };

            // eQuyenLH1


        }
    ])
    .controller('gmap_neutralBlueCtrl', [
        '$scope',
        '$timeout',
        function ($scope, $timeout) {
        }
    ]);
