/**
 * Created by hienpt on 4/19/17.
 */
angular
    .module('altairApp')
    .controller('settingsCtrl', [
        '$rootScope',
        '$scope',
        function ($rootScope,$scope) {
            console.log("Start settings controller");
        }
    ])
;