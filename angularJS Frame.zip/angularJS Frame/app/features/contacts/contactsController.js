/**
 * Created by hienpt on 4/19/17.
 */
angular
    .module('altairApp')
    .controller('contactsCtrl', [
        '$rootScope',
        '$scope',
        function ($rootScope,$scope) {
            console.log("Start contacts controller");
        }
    ])
;