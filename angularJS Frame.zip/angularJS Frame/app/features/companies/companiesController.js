/**
 * Created by hienpt on 4/19/17.
 */
angular
    .module('altairApp')
    .controller('companiesCtrl', [
        '$rootScope',
        '$scope',
        function ($rootScope,$scope) {
            console.log("Start companies controller");
        }
    ])
;