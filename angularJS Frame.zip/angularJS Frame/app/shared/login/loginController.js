/**
 * Created by hienpt on 4/19/17.
 */
angular
    .module('altairApp')
    .controller('loginCtrl', [
        '$rootScope',
        '$scope',
        function ($rootScope,$scope) {
            console.log("Start settings controller");
        }
    ])
;