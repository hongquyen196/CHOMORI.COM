/**
 * Created by hienpt on 4/19/17.
 */
/**
 * Created by hienpt on 1/12/17.
 */
altairApp
    .service('login', [
        '$http',
        function ($http) {
            var vm = this;

            vm.login = function (username, password, appCode) {
                //TODO: Need to implement
            };

            vm.logout = function(token) {
                //TODO: Need to implement
            };

            vm.isValidToken = function(token) {
                //TODO: need to implement
            }
        }
    ])
;