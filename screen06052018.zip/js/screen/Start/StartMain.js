/**
 * Created by mac on 05/05/2018.
 */
'use strict';
var module = angular.module('StartApp', ['StartApp.controllers', 'StartApp.services', 'ngStorage','ngRoute', 'ngMaterial','ngMessages']);
module.constant("CONSTANTS", {
});
